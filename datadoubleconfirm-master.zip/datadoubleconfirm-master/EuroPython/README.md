About
----

This folder contains materials I have used for my talk on ["Top 15 Python Tips for Data Cleaning/ Understanding" at EuroPython 2020 Online](https://ep2020.europython.eu/talks/CivrR5y-top-15-python-tips-for-data-cleaning-understanding/). 

The recording of the 25-min talk is available on YouTube: 

[![Watch the video](youtube_preview.png)](https://youtu.be/-Vlqwtbg1wg)


https://youtu.be/-Vlqwtbg1wg
