# miniproject1

In thi mini project 1, I use Python Pandas & Python Matplotlib to analyze and answer business questions about 12 months worth of sales data. The data contains hundreds of thousands of electronics store purchases broken down by month, product type, cost, purchase address, etc. The dataset can be downloaded in this repository. In this analysis, I’m using jupyter notebook to write the code.

You can see the analysis here: https://mathr1x.medium.com/product-sales-analysis-using-python-863b29026957
